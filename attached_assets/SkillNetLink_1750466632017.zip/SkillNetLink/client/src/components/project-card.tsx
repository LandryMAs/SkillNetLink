import { Link } from "wouter";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Users, 
  Star, 
  GitBranch, 
  ExternalLink, 
  Github,
  Calendar,
  Eye
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";
import type { Project } from "@shared/schema";

interface ProjectCardProps {
  project: Project;
}

export default function ProjectCard({ project }: ProjectCardProps) {
  // Mock creator data - in real app this would come from a join or separate query
  const creator = {
    firstName: "Ahmed",
    lastName: "Sow", 
    profileImageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"
  };

  const timeAgo = formatDistanceToNow(new Date(project.createdAt!), {
    addSuffix: true,
    locale: fr,
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800 border-green-200";
      case "completed":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "paused":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "active":
        return "Actif";
      case "completed":
        return "Terminé";
      case "paused":
        return "En pause";
      default:
        return status;
    }
  };

  return (
    <Card className="hover:shadow-lg transition-all duration-200 group">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="font-semibold text-lg text-gray-900 group-hover:text-tchad-blue transition-colors">
              {project.title}
            </h3>
            <p className="text-sm text-gray-600 mt-1 line-clamp-2">
              {project.description}
            </p>
          </div>
          <Badge 
            variant="outline" 
            className={`ml-2 text-xs ${getStatusColor(project.status!)}`}
          >
            {getStatusText(project.status!)}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Technologies */}
        <div className="flex flex-wrap gap-1">
          {project.technologies?.slice(0, 4).map((tech, index) => (
            <Badge 
              key={index} 
              variant="secondary" 
              className="text-xs bg-gray-100 text-gray-700 hover:bg-gray-200"
            >
              {tech}
            </Badge>
          ))}
          {project.technologies && project.technologies.length > 4 && (
            <Badge variant="secondary" className="text-xs bg-gray-100 text-gray-700">
              +{project.technologies.length - 4}
            </Badge>
          )}
        </div>

        {/* Creator Info */}
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Avatar className="h-6 w-6">
            <AvatarImage 
              src={creator.profileImageUrl}
              alt={`${creator.firstName} ${creator.lastName}`}
            />
            <AvatarFallback className="text-xs">
              {creator.firstName[0]}{creator.lastName[0]}
            </AvatarFallback>
          </Avatar>
          <span>Par {creator.firstName} {creator.lastName}</span>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-4 text-sm text-gray-500">
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            <span>{project.contributorsCount}</span>
          </div>
          <div className="flex items-center gap-1">
            <Calendar className="h-4 w-4" />
            <span>{timeAgo}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 pt-2">
          <Button 
            size="sm" 
            className="flex-1 bg-tchad-blue hover:bg-blue-700 text-white"
          >
            <Eye className="h-4 w-4 mr-2" />
            Voir le projet
          </Button>
          
          <div className="flex gap-1">
            {project.githubUrl && (
              <Button 
                variant="outline" 
                size="sm"
                className="p-2"
                onClick={() => window.open(project.githubUrl!, '_blank')}
              >
                <Github className="h-4 w-4" />
              </Button>
            )}
            
            {project.liveUrl && (
              <Button 
                variant="outline" 
                size="sm"
                className="p-2"
                onClick={() => window.open(project.liveUrl!, '_blank')}
              >
                <ExternalLink className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>

        {/* Join Project */}
        {project.status === "active" && (
          <div className="pt-2 border-t border-gray-100">
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full border-tchad-blue text-tchad-blue hover:bg-tchad-blue hover:text-white"
            >
              <GitBranch className="h-4 w-4 mr-2" />
              Rejoindre le projet
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

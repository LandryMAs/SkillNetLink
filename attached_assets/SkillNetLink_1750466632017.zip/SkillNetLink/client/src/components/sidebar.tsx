import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { MapPin, Users, Code, Plus } from "lucide-react";
import type { User } from "@shared/schema";

interface SidebarProps {
  user: User;
}

export default function Sidebar({ user }: SidebarProps) {
  const skills = user.skills || [];
  
  // Mock skill levels for demonstration
  const skillsWithLevels = skills.slice(0, 5).map((skill, index) => ({
    name: skill,
    level: 70 + (index * 5) // Mock progression levels
  }));

  return (
    <div className="space-y-6">
      {/* Profile Card */}
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <img 
              src={user.profileImageUrl || `https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face`}
              alt={`${user.firstName} ${user.lastName}`}
              className="w-20 h-20 rounded-full mx-auto mb-4 object-cover border-2 border-gray-100"
            />
            <h3 className="text-lg font-semibold text-gray-900 mb-1">
              {user.firstName} {user.lastName}
            </h3>
            <p className="text-sm text-gray-600 mb-2">
              {user.title || "Étudiant"}
            </p>
            {user.location && (
              <div className="flex items-center justify-center text-xs text-gray-500 mb-4">
                <MapPin className="h-3 w-3 mr-1" />
                {user.location}
              </div>
            )}
            
            {/* Stats */}
            <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
              <div className="text-center">
                <div className="text-lg font-bold text-tchad-blue">
                  {user.connections || 0}
                </div>
                <div className="text-gray-500">Connexions</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-tchad-blue">
                  12
                </div>
                <div className="text-gray-500">Projets</div>
              </div>
            </div>
            
            <Link href="/profile">
              <Button className="w-full bg-tchad-blue hover:bg-blue-700 text-white">
                Voir le profil
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
      
      {/* Skills Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold text-gray-900">
              Compétences principales
            </h4>
            <Button variant="ghost" size="sm">
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          
          {skillsWithLevels.length > 0 ? (
            <div className="space-y-3">
              {skillsWithLevels.map((skill, index) => (
                <div key={index}>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-700 font-medium">
                      {skill.name}
                    </span>
                    <span className="text-xs text-gray-500">
                      {skill.level}%
                    </span>
                  </div>
                  <Progress 
                    value={skill.level} 
                    className="h-2"
                  />
                </div>
              ))}
              
              {skills.length > 5 && (
                <div className="pt-2">
                  <Link href="/profile">
                    <Button variant="ghost" size="sm" className="w-full text-xs">
                      Voir toutes les compétences ({skills.length})
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-4">
              <p className="text-sm text-gray-500 mb-3">
                Aucune compétence définie
              </p>
              <Link href="/profile">
                <Button variant="outline" size="sm">
                  Ajouter des compétences
                </Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card className="bg-gradient-to-br from-gray-50 to-gray-100">
        <CardContent className="p-6">
          <h4 className="font-semibold text-gray-900 mb-4">
            Actions rapides
          </h4>
          <div className="space-y-2">
            <Link href="/projects">
              <Button variant="ghost" className="w-full justify-start" size="sm">
                <Code className="h-4 w-4 mr-2" />
                Créer un projet
              </Button>
            </Link>
            <Link href="/users">
              <Button variant="ghost" className="w-full justify-start" size="sm">
                <Users className="h-4 w-4 mr-2" />
                Trouver des collaborateurs
              </Button>
            </Link>
            {(user.role === "mentor_company" || user.role === "admin") && (
              <Link href="/jobs">
                <Button variant="ghost" className="w-full justify-start" size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Publier une offre
                </Button>
              </Link>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

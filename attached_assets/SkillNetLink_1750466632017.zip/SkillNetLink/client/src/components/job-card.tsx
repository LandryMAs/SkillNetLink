import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  MapPin, 
  Building, 
  Clock, 
  DollarSign, 
  ExternalLink,
  Calendar,
  Users,
  Bookmark,
  Share
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";
import type { Job } from "@shared/schema";

interface JobCardProps {
  job: Job;
}

export default function JobCard({ job }: JobCardProps) {
  // Mock poster data - in real app this would come from a join or separate query
  const poster = {
    firstName: "Hassan",
    lastName: "Oumar",
    title: "Développeur Senior • Mentor",
    profileImageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"
  };

  const timeAgo = formatDistanceToNow(new Date(job.createdAt!), {
    addSuffix: true,
    locale: fr,
  });

  const getJobTypeColor = (type: string) => {
    switch (type) {
      case "internship":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "full_time":
        return "bg-green-100 text-green-800 border-green-200";
      case "part_time":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "contract":
        return "bg-purple-100 text-purple-800 border-purple-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getJobTypeText = (type: string) => {
    switch (type) {
      case "internship":
        return "Stage";
      case "full_time":
        return "Temps plein";
      case "part_time":
        return "Temps partiel";
      case "contract":
        return "Contrat";
      default:
        return type;
    }
  };

  const handleApply = () => {
    if (job.applicationUrl) {
      window.open(job.applicationUrl, '_blank');
    } else {
      // In real app: open application modal or redirect to application page
      console.log("Apply to job:", job.id);
    }
  };

  return (
    <Card className="hover:shadow-lg transition-all duration-200">
      <CardHeader className="pb-4">
        <div className="flex items-start gap-3">
          <Avatar className="h-12 w-12">
            <AvatarImage 
              src={poster.profileImageUrl}
              alt={`${poster.firstName} ${poster.lastName}`}
            />
            <AvatarFallback>
              {poster.firstName[0]}{poster.lastName[0]}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold text-lg text-gray-900">
                  {job.title}
                </h3>
                <p className="text-tchad-blue font-medium">
                  {job.company}
                </p>
                <p className="text-sm text-gray-500">
                  Publié par {poster.firstName} {poster.lastName}
                </p>
              </div>
              
              <div className="flex gap-2">
                <Button variant="ghost" size="sm" className="p-2">
                  <Bookmark className="h-4 w-4 text-gray-400 hover:text-tchad-blue" />
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <Share className="h-4 w-4 text-gray-400 hover:text-tchad-blue" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Job Details */}
        <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
          <div className="flex items-center gap-1">
            <MapPin className="h-4 w-4" />
            <span>{job.location || "Non spécifié"}</span>
            {job.isRemote && (
              <Badge variant="outline" className="ml-1 text-xs">
                Remote
              </Badge>
            )}
          </div>
          
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <Badge 
              variant="outline" 
              className={`text-xs ${getJobTypeColor(job.type)}`}
            >
              {getJobTypeText(job.type)}
            </Badge>
          </div>
          
          <div className="flex items-center gap-1">
            <Calendar className="h-4 w-4" />
            <span>{timeAgo}</span>
          </div>
        </div>

        {/* Salary */}
        {job.salary && (
          <div className="flex items-center gap-2 text-sm">
            <DollarSign className="h-4 w-4 text-green-600" />
            <span className="font-medium text-green-700">{job.salary}</span>
          </div>
        )}

        {/* Description */}
        <div>
          <p className="text-gray-700 leading-relaxed line-clamp-3">
            {job.description}
          </p>
        </div>

        {/* Requirements Preview */}
        {job.requirements && job.requirements.length > 0 && (
          <div>
            <h4 className="font-medium text-gray-900 mb-2">Exigences :</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              {job.requirements.slice(0, 3).map((requirement, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="w-1 h-1 bg-tchad-blue rounded-full mt-2 flex-shrink-0"></span>
                  <span className="line-clamp-1">{requirement}</span>
                </li>
              ))}
              {job.requirements.length > 3 && (
                <li className="text-tchad-blue text-sm">
                  +{job.requirements.length - 3} autres exigences...
                </li>
              )}
            </ul>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Button 
            onClick={handleApply}
            className="flex-1 bg-tchad-blue hover:bg-blue-700 text-white"
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            Postuler maintenant
          </Button>
          
          <Button variant="outline" className="border-tchad-blue text-tchad-blue hover:bg-tchad-blue hover:text-white">
            Voir détails
          </Button>
        </div>

        {/* Additional Info */}
        <div className="flex justify-between items-center pt-2 border-t border-gray-100 text-xs text-gray-500">
          <span className="flex items-center gap-1">
            <Building className="h-3 w-3" />
            Entreprise vérifiée
          </span>
          <span className="flex items-center gap-1">
            <Users className="h-3 w-3" />
            {Math.floor(Math.random() * 50) + 10} candidatures
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  ThumbsUp, 
  MessageCircle, 
  Share, 
  Bookmark, 
  MoreHorizontal,
  ExternalLink,
  Calendar,
  Building
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";
import type { Post } from "@shared/schema";

interface PostCardProps {
  post: Post;
}

export default function PostCard({ post }: PostCardProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);

  // Mock author data - in real app this would come from a join or separate query
  const author = {
    firstName: "Fatima",
    lastName: "Ibrahim",
    title: "Étudiante en Génie Logiciel",
    profileImageUrl: "https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?w=150&h=150&fit=crop&crop=face"
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
    // In real app: trigger like/unlike mutation
  };

  const handleBookmark = () => {
    setIsBookmarked(!isBookmarked);
    // In real app: trigger bookmark/unbookmark mutation
  };

  const handleShare = () => {
    // In real app: implement share functionality
    navigator.share?.({
      title: "SkillLink Post",
      text: post.content.substring(0, 100) + "...",
      url: window.location.href,
    });
  };

  const timeAgo = formatDistanceToNow(new Date(post.createdAt!), {
    addSuffix: true,
    locale: fr,
  });

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-start space-x-3">
            <Avatar className="h-12 w-12">
              <AvatarImage 
                src={author.profileImageUrl}
                alt={`${author.firstName} ${author.lastName}`}
              />
              <AvatarFallback>
                {author.firstName[0]}{author.lastName[0]}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h4 className="font-semibold text-gray-900">
                {author.firstName} {author.lastName}
              </h4>
              <p className="text-sm text-gray-500 mb-1">
                {author.title}
              </p>
              <div className="flex items-center text-xs text-gray-400">
                <Calendar className="h-3 w-3 mr-1" />
                {timeAgo}
              </div>
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                Signaler le contenu
              </DropdownMenuItem>
              <DropdownMenuItem>
                Masquer le post
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        {/* Content */}
        <div className="mb-4">
          <p className="text-gray-700 leading-relaxed mb-3">
            {post.content}
          </p>
          
          {/* Image if present */}
          {post.imageUrl && (
            <img 
              src={post.imageUrl}
              alt="Post content"
              className="w-full h-64 object-cover rounded-lg border"
            />
          )}
          
          {/* Post type specific content */}
          {post.type === "project" && (
            <div className="bg-gradient-to-r from-tchad-blue to-blue-600 text-white p-4 rounded-lg mt-3">
              <div className="flex items-center gap-2 mb-2">
                <Building className="h-4 w-4" />
                <span className="font-medium">Projet Collaboratif</span>
              </div>
              <h5 className="font-semibold mb-2">Application Mobile de Gestion</h5>
              <p className="text-sm opacity-90 mb-3">
                Recherche collaborateurs • React Native • PostgreSQL
              </p>
              <Button 
                size="sm" 
                className="bg-white text-tchad-blue hover:bg-gray-100"
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                Voir le projet
              </Button>
            </div>
          )}
          
          {post.type === "job" && (
            <div className="bg-gradient-to-r from-tchad-yellow to-yellow-500 text-gray-900 p-4 rounded-lg mt-3">
              <div className="flex items-center gap-2 mb-2">
                <Building className="h-4 w-4" />
                <span className="font-medium">Offre d'Emploi</span>
              </div>
              <h5 className="font-semibold mb-2">Stage Développeur Full-Stack</h5>
              <p className="text-sm opacity-90 mb-3">
                3-6 mois • Ouagadougou • Rémunéré
              </p>
              <Button 
                size="sm" 
                className="bg-white text-tchad-yellow hover:bg-gray-100"
              >
                Postuler maintenant
              </Button>
            </div>
          )}
        </div>
        
        {/* Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-gray-100">
          <div className="flex items-center space-x-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLike}
              className={`flex items-center space-x-2 ${
                isLiked ? "text-tchad-blue" : "text-gray-500 hover:text-tchad-blue"
              }`}
            >
              <ThumbsUp className={`h-4 w-4 ${isLiked ? "fill-current" : ""}`} />
              <span className="text-sm">
                {(post.likesCount || 0) + (isLiked ? 1 : 0)}
              </span>
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-2 text-gray-500 hover:text-tchad-blue"
            >
              <MessageCircle className="h-4 w-4" />
              <span className="text-sm">{post.commentsCount || 0}</span>
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={handleShare}
              className="flex items-center space-x-2 text-gray-500 hover:text-tchad-blue"
            >
              <Share className="h-4 w-4" />
              <span className="text-sm">{post.sharesCount || 0}</span>
            </Button>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={handleBookmark}
            className={`${
              isBookmarked ? "text-tchad-blue" : "text-gray-400 hover:text-tchad-blue"
            }`}
          >
            <Bookmark className={`h-4 w-4 ${isBookmarked ? "fill-current" : ""}`} />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

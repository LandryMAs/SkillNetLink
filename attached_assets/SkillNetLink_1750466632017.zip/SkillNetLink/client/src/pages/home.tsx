import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/sidebar";
import PostCard from "@/components/post-card";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Image, Code, Briefcase } from "lucide-react";
import type { Post, User } from "@shared/schema";

export default function Home() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  const { data: posts = [], isLoading: postsLoading } = useQuery<Post[]>({
    queryKey: ["/api/posts"],
    enabled: isAuthenticated,
  });

  const { data: recentActivity = [] } = useQuery<any[]>({
    queryKey: ["/api/admin/stats"],
    enabled: isAuthenticated,
  });

  const { data: trendingProjects = [] } = useQuery<any[]>({
    queryKey: ["/api/projects"],
    enabled: isAuthenticated,
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Non autorisé",
        description: "Vous devez vous connecter pour accéder à cette page.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-tchad-blue"></div>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return null;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Left Sidebar */}
        <div className="lg:col-span-1">
          <Sidebar user={user} />
        </div>

        {/* Main Content */}
        <div className="lg:col-span-2">
          {/* Quick Actions */}
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="flex items-center space-x-4 mb-4">
                <img 
                  src={user.profileImageUrl || `https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face`} 
                  alt="Profile" 
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div className="flex-1">
                  <Textarea
                    placeholder="Partager un projet ou une expérience..."
                    className="resize-none"
                    rows={2}
                  />
                </div>
              </div>
              <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                <Button variant="ghost" className="flex items-center space-x-2">
                  <Image className="h-5 w-5 text-tchad-blue" />
                  <span>Photo</span>
                </Button>
                <Button variant="ghost" className="flex items-center space-x-2">
                  <Code className="h-5 w-5 text-tchad-yellow" />
                  <span>Projet</span>
                </Button>
                <Button variant="ghost" className="flex items-center space-x-2">
                  <Briefcase className="h-5 w-5 text-tchad-red" />
                  <span>Expérience</span>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Feed Posts */}
          <div className="space-y-6">
            {postsLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-tchad-blue"></div>
              </div>
            ) : posts.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <p className="text-gray-500">Aucun post à afficher pour le moment.</p>
                  <p className="text-sm text-gray-400 mt-2">
                    Commencez par suivre d'autres utilisateurs ou créez votre premier post !
                  </p>
                </CardContent>
              </Card>
            ) : (
              posts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))
            )}
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="lg:col-span-1">
          {/* Recent Activity */}
          <Card className="mb-6">
            <CardContent className="p-6">
              <h4 className="font-semibold text-gray-900 mb-4">Activité récente</h4>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-tchad-blue rounded-full mt-3"></div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-700">
                      Nouveaux utilisateurs rejoignent la plateforme
                    </p>
                    <p className="text-xs text-gray-500">Il y a 2h</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-tchad-yellow rounded-full mt-3"></div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-700">
                      Nouveaux projets collaboratifs disponibles
                    </p>
                    <p className="text-xs text-gray-500">Il y a 4h</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-tchad-red rounded-full mt-3"></div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-700">
                      Nouvelles offres d'emploi publiées
                    </p>
                    <p className="text-xs text-gray-500">Il y a 6h</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Trending Projects */}
          <Card className="mb-6">
            <CardContent className="p-6">
              <h4 className="font-semibold text-gray-900 mb-4">Projets populaires</h4>
              <div className="space-y-4">
                <div className="border-l-4 border-tchad-blue pl-4">
                  <h5 className="font-medium text-gray-900 text-sm">E-Learning Platform</h5>
                  <p className="text-xs text-gray-500 mb-2">12 contributeurs</p>
                  <div className="flex flex-wrap gap-1">
                    <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">React</span>
                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">Node.js</span>
                  </div>
                </div>
                <div className="border-l-4 border-tchad-yellow pl-4">
                  <h5 className="font-medium text-gray-900 text-sm">Gestion Coopérative</h5>
                  <p className="text-xs text-gray-500 mb-2">8 contributeurs</p>
                  <div className="flex flex-wrap gap-1">
                    <span className="px-2 py-1 bg-orange-100 text-orange-800 text-xs rounded-full">Laravel</span>
                    <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded-full">MySQL</span>
                  </div>
                </div>
                <div className="border-l-4 border-tchad-red pl-4">
                  <h5 className="font-medium text-gray-900 text-sm">Health Tracker</h5>
                  <p className="text-xs text-gray-500 mb-2">15 contributeurs</p>
                  <div className="flex flex-wrap gap-1">
                    <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">Flutter</span>
                    <span className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full">Firebase</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card className="bg-gradient-to-br from-tchad-blue to-blue-700 text-white">
            <CardContent className="p-6">
              <h4 className="font-semibold mb-4">Statistiques rapides</h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm opacity-90">Étudiants actifs</span>
                  <span className="font-bold">2,847</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm opacity-90">Projets en cours</span>
                  <span className="font-bold">156</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm opacity-90">Offres disponibles</span>
                  <span className="font-bold">23</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm opacity-90">Mentors actifs</span>
                  <span className="font-bold">89</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

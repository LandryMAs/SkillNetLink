import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Filter, MapPin, Clock, User } from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertServiceSchema } from "@shared/schema";
import type { Service } from "@shared/schema";

const serviceCategories = [
  { value: "cleaning", label: "Nettoyage" },
  { value: "cooking", label: "Cuisine" },
  { value: "tutoring", label: "Tutorat" },
  { value: "tech_support", label: "Support technique" },
  { value: "sewing", label: "Couture" },
  { value: "laundry", label: "Lessive" },
  { value: "delivery", label: "Livraison" },
  { value: "gardening", label: "Jardinage" },
  { value: "other", label: "Autre" },
];

type ServiceForm = z.infer<typeof insertServiceSchema>;

const serviceFormSchema = insertServiceSchema.extend({
  price: z.string().min(1, "Le prix est requis"),
  location: z.string().min(1, "La localisation est requise"),
}).omit({
  providerId: true,
});

export default function Services() {
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [showAddService, setShowAddService] = useState(false);
  const { toast } = useToast();

  const { data: services = [], isLoading } = useQuery({
    queryKey: selectedCategory ? ['/api/services', selectedCategory] : ['/api/services'],
    queryFn: () => 
      selectedCategory 
        ? fetch(`/api/services?category=${selectedCategory}`).then(res => res.json())
        : fetch('/api/services').then(res => res.json())
  });

  const form = useForm<ServiceForm>({
    resolver: zodResolver(serviceFormSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "",
      price: "",
      location: "",
      isAvailable: true,
    },
  });

  const createServiceMutation = useMutation({
    mutationFn: async (data: ServiceForm) => {
      const response = await fetch('/api/services', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Erreur lors de la création du service');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
      toast({
        title: "Service créé",
        description: "Votre service a été créé avec succès.",
      });
      setShowAddService(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Impossible de créer le service.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ServiceForm) => {
    createServiceMutation.mutate(data);
  };

  const getCategoryLabel = (category: string) => {
    return serviceCategories.find(cat => cat.value === category)?.label || category;
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Services</h1>
          <p className="text-gray-600 dark:text-gray-300">
            Proposez vos services ou trouvez l'aide dont vous avez besoin
          </p>
        </div>
        <Dialog open={showAddService} onOpenChange={setShowAddService}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              Proposer un service
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Proposer un nouveau service</DialogTitle>
              <DialogDescription>
                Créez une offre de service pour aider d'autres étudiants
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Titre du service</FormLabel>
                      <FormControl>
                        <Input placeholder="Ex: Nettoyage de chambre" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Décrivez votre service en détail..."
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Catégorie</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionnez une catégorie" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {serviceCategories.map((category) => (
                            <SelectItem key={category.value} value={category.value}>
                              {category.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Prix</FormLabel>
                      <FormControl>
                        <Input placeholder="Ex: 2000 FCFA" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Localisation</FormLabel>
                      <FormControl>
                        <Input placeholder="Ex: Campus Université de Ouagadougou" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  disabled={createServiceMutation.isPending}
                >
                  {createServiceMutation.isPending ? "Création..." : "Créer le service"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        <Button
          variant={selectedCategory === "" ? "default" : "outline"}
          size="sm"
          onClick={() => setSelectedCategory("")}
          className="mb-2"
        >
          <Filter className="h-4 w-4 mr-2" />
          Tous
        </Button>
        {serviceCategories.map((category) => (
          <Button
            key={category.value}
            variant={selectedCategory === category.value ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedCategory(category.value)}
            className="mb-2"
          >
            {category.label}
          </Button>
        ))}
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((service: Service) => (
          <ServiceCard key={service.id} service={service} />
        ))}
      </div>

      {services.length === 0 && (
        <div className="text-center py-8">
          <p className="text-gray-500 dark:text-gray-400">
            Aucun service disponible pour le moment.
          </p>
        </div>
      )}
    </div>
  );
}

function ServiceCard({ service }: { service: Service }) {
  const [showRequest, setShowRequest] = useState(false);
  const { toast } = useToast();

  const requestForm = useForm({
    defaultValues: {
      message: "",
      requestedDate: "",
    },
  });

  const createRequestMutation = useMutation({
    mutationFn: async (data: { message: string; requestedDate?: string }) => {
      const response = await fetch('/api/service-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          serviceId: service.id,
          message: data.message,
          requestedDate: data.requestedDate ? new Date(data.requestedDate) : null,
        }),
      });
      if (!response.ok) throw new Error('Erreur lors de la demande');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Demande envoyée",
        description: "Votre demande a été soumise à l'administrateur pour approbation.",
      });
      setShowRequest(false);
      requestForm.reset();
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible d'envoyer la demande.",
        variant: "destructive",
      });
    },
  });

  const onRequestSubmit = (data: { message: string; requestedDate: string }) => {
    createRequestMutation.mutate(data);
  };

  const getCategoryLabel = (category: string) => {
    return serviceCategories.find(cat => cat.value === category)?.label || category;
  };

  return (
    <Card className="h-full">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <CardTitle className="text-lg">{service.title}</CardTitle>
            <CardDescription className="mt-1">{service.description}</CardDescription>
          </div>
          <Badge variant="secondary" className="ml-2">
            {getCategoryLabel(service.category)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
            <MapPin className="h-4 w-4 mr-2" />
            {service.location}
          </div>
          <div className="flex items-center text-sm font-medium text-green-600">
            <span className="mr-2">💰</span>
            {service.price}
          </div>
          <div className="flex items-center text-sm text-gray-500">
            <Clock className="h-4 w-4 mr-2" />
            {new Date(service.createdAt).toLocaleDateString('fr-FR')}
          </div>
          <Dialog open={showRequest} onOpenChange={setShowRequest}>
            <DialogTrigger asChild>
              <Button className="w-full bg-yellow-600 hover:bg-yellow-700">
                Demander ce service
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Demander le service</DialogTitle>
                <DialogDescription>
                  Votre demande sera envoyée à l'administrateur pour approbation
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={requestForm.handleSubmit(onRequestSubmit)} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Message (optionnel)
                  </label>
                  <Textarea
                    placeholder="Détails supplémentaires sur votre demande..."
                    {...requestForm.register("message")}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Date souhaitée (optionnel)
                  </label>
                  <Input
                    type="datetime-local"
                    {...requestForm.register("requestedDate")}
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full bg-yellow-600 hover:bg-yellow-700"
                  disabled={createRequestMutation.isPending}
                >
                  {createRequestMutation.isPending ? "Envoi..." : "Envoyer la demande"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardContent>
    </Card>
  );
}
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, UserPlus, MessageCircle, CheckCircle, XCircle, Clock } from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { User, Connection } from "@shared/schema";

export default function Connections() {
  const [showConnectDialog, setShowConnectDialog] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const { toast } = useToast();

  const { data: users = [], isLoading: usersLoading } = useQuery({
    queryKey: ['/api/users'],
  });

  const { data: connections = [], isLoading: connectionsLoading } = useQuery({
    queryKey: ['/api/connections'],
  });

  const { data: pendingConnections = [], isLoading: pendingLoading } = useQuery({
    queryKey: ['/api/connections/pending'],
  });

  const connectForm = useForm({
    defaultValues: {
      requestMessage: "",
    },
  });

  const sendConnectionMutation = useMutation({
    mutationFn: async (data: { connectedUserId: string; requestMessage: string }) => {
      const response = await fetch('/api/connections', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Erreur lors de l\'envoi de la demande');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/connections'] });
      toast({
        title: "Demande envoyée",
        description: "Votre demande de connexion a été envoyée.",
      });
      setShowConnectDialog(false);
      setSelectedUser(null);
      connectForm.reset();
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible d'envoyer la demande de connexion.",
        variant: "destructive",
      });
    },
  });

  const respondToConnectionMutation = useMutation({
    mutationFn: async ({ connectionId, action }: { connectionId: number; action: 'accept' | 'reject' }) => {
      const response = await fetch(`/api/connections/${connectionId}/${action}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error(`Erreur lors de ${action === 'accept' ? 'l\'acceptation' : 'le rejet'}`);
      return response.json();
    },
    onSuccess: (_, { action }) => {
      queryClient.invalidateQueries({ queryKey: ['/api/connections'] });
      toast({
        title: action === 'accept' ? "Connexion acceptée" : "Connexion refusée",
        description: action === 'accept' ? "Vous êtes maintenant connectés." : "La demande a été refusée.",
      });
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible de traiter la demande.",
        variant: "destructive",
      });
    },
  });

  const handleConnect = (user: User) => {
    setSelectedUser(user);
    setShowConnectDialog(true);
  };

  const onConnectSubmit = (data: { requestMessage: string }) => {
    if (!selectedUser) return;
    sendConnectionMutation.mutate({
      connectedUserId: selectedUser.id,
      requestMessage: data.requestMessage,
    });
  };

  const handleConnectionResponse = (connectionId: number, action: 'accept' | 'reject') => {
    respondToConnectionMutation.mutate({ connectionId, action });
  };

  if (usersLoading || connectionsLoading || pendingLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const connectedUserIds = new Set(connections.map((conn: Connection) => 
    conn.status === 'accepted' ? (conn.userId !== conn.connectedUserId ? conn.connectedUserId : conn.userId) : null
  ).filter(Boolean));

  const pendingUserIds = new Set(connections.map((conn: Connection) => 
    conn.status === 'pending' ? conn.connectedUserId : null
  ).filter(Boolean));

  const availableUsers = users.filter((user: User) => 
    !connectedUserIds.has(user.id) && !pendingUserIds.has(user.id)
  );

  const connectedUsers = users.filter((user: User) => connectedUserIds.has(user.id));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Connexions</h1>
          <p className="text-gray-600 dark:text-gray-300">
            Développez votre réseau professionnel avec d'autres étudiants tchadiens
          </p>
        </div>
      </div>

      <Tabs defaultValue="discover" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="discover" className="flex items-center gap-2">
            <UserPlus className="h-4 w-4" />
            Découvrir ({availableUsers.length})
          </TabsTrigger>
          <TabsTrigger value="connected" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Mes connexions ({connectedUsers.length})
          </TabsTrigger>
          <TabsTrigger value="pending" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            En attente ({pendingConnections.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="discover" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {availableUsers.map((user: User) => (
              <UserCard 
                key={user.id} 
                user={user} 
                onConnect={() => handleConnect(user)}
                actionType="connect"
              />
            ))}
          </div>
          {availableUsers.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">
                Aucun nouvel utilisateur à découvrir pour le moment.
              </p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="connected" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {connectedUsers.map((user: User) => (
              <UserCard 
                key={user.id} 
                user={user} 
                actionType="message"
              />
            ))}
          </div>
          {connectedUsers.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">
                Vous n'avez pas encore de connexions.
              </p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="pending" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pendingConnections.map((connection: Connection) => {
              const user = users.find((u: User) => u.id === connection.userId);
              if (!user) return null;
              
              return (
                <PendingConnectionCard
                  key={connection.id}
                  user={user}
                  connection={connection}
                  onRespond={(action) => handleConnectionResponse(connection.id, action)}
                />
              );
            })}
          </div>
          {pendingConnections.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">
                Aucune demande de connexion en attente.
              </p>
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={showConnectDialog} onOpenChange={setShowConnectDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Demande de connexion</DialogTitle>
            <DialogDescription>
              Envoyez une demande de connexion à {selectedUser?.firstName} {selectedUser?.lastName}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={connectForm.handleSubmit(onConnectSubmit)} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                Message personnalisé (optionnel)
              </label>
              <Textarea
                placeholder="Bonjour, j'aimerais me connecter avec vous pour..."
                {...connectForm.register("requestMessage")}
              />
            </div>
            <Button 
              type="submit" 
              className="w-full bg-blue-600 hover:bg-blue-700"
              disabled={sendConnectionMutation.isPending}
            >
              {sendConnectionMutation.isPending ? "Envoi..." : "Envoyer la demande"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function UserCard({ 
  user, 
  onConnect, 
  actionType 
}: { 
  user: User; 
  onConnect?: () => void; 
  actionType: 'connect' | 'message' 
}) {
  return (
    <Card className="h-full">
      <CardHeader className="text-center">
        <Avatar className="w-16 h-16 mx-auto">
          <AvatarImage src={user.profileImageUrl || undefined} />
          <AvatarFallback>
            {user.firstName?.charAt(0)}{user.lastName?.charAt(0)}
          </AvatarFallback>
        </Avatar>
        <CardTitle className="text-lg">
          {user.firstName} {user.lastName}
        </CardTitle>
        <CardDescription>
          {user.title || "Étudiant"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {user.bio && (
            <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-2">
              {user.bio}
            </p>
          )}
          {user.location && (
            <p className="text-xs text-gray-500">📍 {user.location}</p>
          )}
          {user.skills && (
            <div className="flex flex-wrap gap-1">
              {user.skills.slice(0, 3).map((skill, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {skill}
                </Badge>
              ))}
              {user.skills.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{user.skills.length - 3}
                </Badge>
              )}
            </div>
          )}
          {actionType === 'connect' && onConnect && (
            <Button onClick={onConnect} className="w-full bg-blue-600 hover:bg-blue-700">
              <UserPlus className="h-4 w-4 mr-2" />
              Se connecter
            </Button>
          )}
          {actionType === 'message' && (
            <Button className="w-full bg-green-600 hover:bg-green-700">
              <MessageCircle className="h-4 w-4 mr-2" />
              Envoyer un message
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function PendingConnectionCard({ 
  user, 
  connection, 
  onRespond 
}: { 
  user: User; 
  connection: Connection; 
  onRespond: (action: 'accept' | 'reject') => void 
}) {
  return (
    <Card className="h-full">
      <CardHeader className="text-center">
        <Avatar className="w-16 h-16 mx-auto">
          <AvatarImage src={user.profileImageUrl || undefined} />
          <AvatarFallback>
            {user.firstName?.charAt(0)}{user.lastName?.charAt(0)}
          </AvatarFallback>
        </Avatar>
        <CardTitle className="text-lg">
          {user.firstName} {user.lastName}
        </CardTitle>
        <CardDescription>
          {user.title || "Étudiant"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {connection.requestMessage && (
            <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-md">
              <p className="text-sm text-gray-600 dark:text-gray-300">
                "{connection.requestMessage}"
              </p>
            </div>
          )}
          <p className="text-xs text-gray-500">
            Demande reçue le {new Date(connection.createdAt).toLocaleDateString('fr-FR')}
          </p>
          <div className="flex gap-2">
            <Button 
              onClick={() => onRespond('accept')}
              className="flex-1 bg-green-600 hover:bg-green-700"
              size="sm"
            >
              <CheckCircle className="h-4 w-4 mr-1" />
              Accepter
            </Button>
            <Button 
              onClick={() => onRespond('reject')}
              variant="outline"
              className="flex-1"
              size="sm"
            >
              <XCircle className="h-4 w-4 mr-1" />
              Refuser
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
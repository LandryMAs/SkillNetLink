import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Code, Briefcase, MessageCircle, Star, ArrowRight } from "lucide-react";

export default function Landing() {
  const features = [
    {
      icon: <Users className="h-8 w-8 text-tchad-blue" />,
      title: "Réseau Professionnel",
      description: "Connectez-vous avec des étudiants tchadiens du monde entier"
    },
    {
      icon: <Code className="h-8 w-8 text-tchad-yellow" />,
      title: "Projets Collaboratifs",
      description: "Participez à des projets innovants et développez vos compétences"
    },
    {
      icon: <Briefcase className="h-8 w-8 text-tchad-red" />,
      title: "Opportunités d'Emploi",
      description: "Découvrez des stages et emplois adaptés à votre profil"
    },
    {
      icon: <MessageCircle className="h-8 w-8 text-tchad-blue" />,
      title: "Mentorat",
      description: "Bénéficiez de l'accompagnement de professionnels expérimentés"
    }
  ];

  const stats = [
    { number: "2,847", label: "Étudiants actifs" },
    { number: "156", label: "Projets en cours" },
    { number: "89", label: "Mentors" },
    { number: "23", label: "Offres d'emploi" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 tchad-gradient rounded-lg mr-3"></div>
              <span className="text-2xl font-bold text-tchad-blue">SkillLink</span>
            </div>
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="bg-tchad-blue hover:bg-blue-700 text-white"
            >
              Se connecter
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Votre réseau professionnel
            <span className="block text-tchad-blue">d'étudiants tchadiens</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Connectez-vous, collaborez et construisez votre avenir professionnel avec 
            une communauté d'étudiants tchadiens motivés au Burkina Faso.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg"
              onClick={() => window.location.href = '/api/login'}
              className="bg-tchad-blue hover:bg-blue-700 text-white px-8 py-3"
            >
              Rejoindre la communauté
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="border-tchad-blue text-tchad-blue hover:bg-tchad-blue hover:text-white px-8 py-3"
            >
              Découvrir les fonctionnalités
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Tout ce dont vous avez besoin pour réussir
            </h2>
            <p className="text-xl text-gray-600">
              Une plateforme complète pour développer votre carrière
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-center mb-4">
                    {feature.icon}
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-tchad-blue">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white mb-4">
              Une communauté qui grandit
            </h2>
            <p className="text-xl text-blue-100">
              Rejoignez des milliers d'étudiants tchadiens déjà connectés
            </p>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-white mb-2">{stat.number}</div>
                <div className="text-blue-100">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-tchad-blue via-tchad-yellow to-tchad-red">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white mb-4">
            Prêt à transformer votre avenir professionnel ?
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Rejoignez SkillLink aujourd'hui et connectez-vous avec votre communauté
          </p>
          <Button 
            size="lg"
            onClick={() => window.location.href = '/api/login'}
            className="bg-white text-tchad-blue hover:bg-gray-100 px-8 py-3 font-semibold"
          >
            Commencer maintenant
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center mb-8">
            <div className="w-8 h-8 tchad-gradient rounded-lg mr-3"></div>
            <span className="text-2xl font-bold">SkillLink</span>
          </div>
          <div className="text-center text-gray-400">
            <p>&copy; 2024 SkillLink. Tous droits réservés.</p>
            <p className="mt-2">Connecter les étudiants tchadiens du monde entier</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
